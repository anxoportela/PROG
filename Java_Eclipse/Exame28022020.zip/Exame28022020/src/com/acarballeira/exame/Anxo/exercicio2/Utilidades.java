package com.acarballeira.exame.Anxo.exercicio2;

import java.io.File;
import java.util.Comparator;

/**
 *
 * @author dual108
 * @date 28 feb. 2020
 * @version 1.0
 *
 */

public interface Utilidades {
	
	public static String [] palabrasSenRepeticion(File f) {
		return null;
	}

}
