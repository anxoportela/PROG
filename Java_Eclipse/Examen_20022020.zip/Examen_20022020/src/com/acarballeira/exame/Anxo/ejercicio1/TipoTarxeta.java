package com.acarballeira.exame.Anxo.ejercicio1;

/**
 *
 * @author dual108
 * @date 20 feb. 2020
 * @version 1.0
 *
 */

public enum TipoTarxeta {
	CREDITO,DEBITO,MONEDEIRO,FINANCIACION
}
